function love.conf(t)
  t.window.title = "Metroidvania Prototype"
  t.window.icon = "bob.png"
end