Duck = Entity:extend()

function 
Duck:new(x, y)
  Duck.super.new(self, x, y, "duck.png")
end

  