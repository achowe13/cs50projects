Heart = Entity:extend()

function Heart:new(x, y)
  Heart.super.new(self, x, y, "heart.png")
end

  